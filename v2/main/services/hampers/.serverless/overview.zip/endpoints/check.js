const Responses = require('../common/API_Responses');
const Dynamo = require('../common/Dynamo');
const Hashing = require('../common/Hashing');
const Functions = require('../common/Functions');

const validations = [
    {
        key: 'campaignId',
        required: true,
        errorMsg: 'Campaign ID is required',
    },
    {
        key: 'hamperId',
        required: true,
        errorMsg: 'Hamper ID is required',
    },
];

exports.handler = async (event, context, cb) => {
    try {
        const mainTableName = process.env.MAIN_DYNAMO_TABLE;

        const parsed = event.nominatorId ? event : JSON.parse(event.body);
        
        const valid = await Functions.validateSubmission(parsed, validations);
        if (Object.keys(valid).length > 0) {
            return Responses._400({ messages: valid });
        }
        
        const campaignQueryData = {
            TableName: mainTableName,
            IndexName: "GSI1",
            FilterExpression: "#pk= :pk AND begins_with(#sk, :sk)",
            ExpressionAttributeValues: {
                ":pk": parsed.campaignId,
                ":sk": "A",
            },
            ExpressionAttributeNames: {
                "#pk": "GSI1PK",
                "#sk": "GSI1SK",
            },
        };
        var campaignData = await Dynamo.scan(campaignQueryData).catch((err) => {
            console.log("error in dynamo query", err);
            return Responses._400({ messages: err });
        });

        const hamper = campaignData.find((h) => h.GSI2SK === `SK#${parsed.hamperId}`);
        if (hamper && hamper?.PK) {
            const returnRes = {
                success: true, 
                bagsReceived: hamper?.bagsReceived ? hamper.bagsReceived : 0,
                familyUnitTotal: hamper?.totalUnit ?? 0,
                familyDynamic: await Functions.generateFamilyDynamics({reference: parsed.hamperId}, hamper?.members ?? [])
            };
            if (returnRes.bagsReceived > 0) {
                returnRes.success = false;
                returnRes.messages = { 'error': 'This hamper has already been received!' };
            }
            return Responses._200(returnRes)
        } else {
            return Responses._400({ messages: { 'error': 'Hamper ID not found' } });
        }

    } catch (e) {
        console.log(`An unexpected error occurred ${e}`);
        return Responses._400({ messages: { 'unexpected': 'An unexpected error occurred' } });
    }
};